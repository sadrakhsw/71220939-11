t_A = (90,90,90,90)
t_B = set (t_A)

if len(t_B)==1:
    print(True)
else:
    print(False)