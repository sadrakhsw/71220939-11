Data = ("Sadrakh Satria Wibowo" , "71220939" , "Sayidan", "DI Yogyakarta")
print(Data)
print("NIM : ",Data[0])
print("NAMA : ",Data[1])
print("ALAMAT : ",Data[2])
print()

NIM = Data[1]
p = tuple(NIM)
print("NIM :",p)
print()

tpl = tuple(Data[0])
q = tpl
tpl1 = tuple(q[1:])
print("NAMA DEPAN :",tpl1)
print()

namakebalik = Data[0]
r = namakebalik.split()
r.reverse()
print("NAMA TERBALIK : ",r)