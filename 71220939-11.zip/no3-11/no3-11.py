file_nama = input("Enter a File name : ")
dict_hours = dict()
st = list()
try:
    fhand = open(file_nama)
except:
    print(f"{file_nama} not found!")
    exit
for line in fhand:
    kata = line.split()
    if len(kata) < 2 or kata[0] != "From":
        continue
    col_pos = kata[5].split(":")
    hour = col_pos[0]
    if hour not in dict_hours:
        dict_hours[hour] = 1
    else:
        dict_hours[hour] += 1
for key, val in list(dict_hours.items()):
    st.append((key,val))
st.sort()
for key,val in st:
    print(key,val)